<?php

// Variables Conexión
define( 'V_HOSTNAME', 'localhost' );
define( 'V_USERNAME', 'root' );
define( 'V_PASSWORD', '' );
define( 'V_TYPE', 'mysqli' );
define( 'V_DATABASE', 'leangasoftware_php' );